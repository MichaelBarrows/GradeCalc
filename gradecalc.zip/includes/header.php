<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html"/>
    <meta name="keywords" content="University, Module, Year, Grade, Calculator, Average, Percentage, Student, Degree, Classification"/>
    <meta name="description" content="An easy way to calculate your weighted module and year university grades with classifications."/>
    <meta name="author" content="Michael Barrows"/>
    <link rel="canonical" href="https://www.gradecalc.com"/>
