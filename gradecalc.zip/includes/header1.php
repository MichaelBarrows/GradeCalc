    <link rel="stylesheet" href="/css/app.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/vendor/modernizr.js"></script>
    <script src="/js/foundation.min.js"></script>
</head>
<body>

<header class="row">
    <div class="small-12 large-12 columns">
        <h1><a href="/">Grade Calculator</a></h1>
    </div>
</header>
<div class="row">
    <nav class="top-bar" data-topbar role="navigation">
        <section class="top-bar-section">
            <ul class="right">
                <li><a href="/about/">About</a></li>
            </ul>
            <ul class="left">
                <li><a href="/module/">Module Grade</a></li>
                <li><a href="/year/">Year Grade</a></li>
            </ul>
        </section>
    </nav>
</div>